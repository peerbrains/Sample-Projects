<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
  $(document).ready(function(){
    $(document).on('change', 'input[type="checkbox"]', function(){
alert("hi");
    });
    $(document).ready(function(){
    var categoryID=2007;
    var op="";
    $.ajax({
      type:'get',
      url:'<?php echo URL::to('getLogo'); ?>',
      data:{'id':categoryID},
      success:function(data)
      {
         console.log(data);
        /*op+="<label>Amount</label></br>";
         for(var i=0;i<data.length;i++)
         {
          op+='<label class="main"><input type="checkbox" name="Color" value="'+data[i].Color+'"/><span class="geekmark" style="background-color:'+data[i].Color+';"></span></label>';
         }  
         $("#color").html("");
         $("#color").append(op);*/
      }
      
    });
  });
  

});
</script>
</head>
<body>
<input type="checkbox" />

























</body>
</html>

<?php /**PATH E:\Laravel\PhotoChat\resources\views/autopostback.blade.php ENDPATH**/ ?>