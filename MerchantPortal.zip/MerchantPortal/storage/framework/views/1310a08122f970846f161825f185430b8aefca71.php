
<?php $__env->startSection('maincontent'); ?>
<div class="container">
  <div class="row">
  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-md-4">
      <div class="thumbnail">
      <img src="data:image/png;base64,<?php echo e(chunk_split(base64_encode(($row->CompanyLogo)))); ?>"  height="180" width="150"/>
  <div class="caption">
           <center> <a href="<?php echo e(url('name/'.$row->CompanyName)); ?>"><?php echo e($row->CompanyName); ?></a></center>
          </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidemenu'); ?>
<a href="<?php echo e(url('clientRegister')); ?>">Add</a>
<a href="<?php echo e(url('clientdetails')); ?>">View</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('stylecontent'); ?>
<style>
.sidenav{
  height:700px;
}
</style>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\MerchantPortal\resources\views/image.blade.php ENDPATH**/ ?>