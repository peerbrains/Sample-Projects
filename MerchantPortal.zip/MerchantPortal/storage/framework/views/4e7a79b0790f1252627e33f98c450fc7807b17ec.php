
<?php $__env->startSection('maincontent'); ?>
<?php $__currentLoopData = $clientDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div aling="center" style="margin-left:180px;">
<img src="data:image/png;base64,<?php echo e(chunk_split(base64_encode(($client->CompanyLogo)))); ?>"  height="80" width="200"/>
<h5>CompanyName-<?php echo e($client->CompanyName); ?></h5>
<h5>CreatedBy-<?php echo e($client->CreatedBy); ?></h5>
<h5>UpdatedBy-<?php echo e($client->UpdatedBy); ?></h5>
<h5>CreatedOn-<?php echo e($client->CreatedOn); ?></h5>
<h5>UpdatedOn-<?php echo e($client->UpdatedOn); ?></h5>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidemenu'); ?>
<a href="<?php echo e(url('clientRegister')); ?>">Add</a>
<a href="<?php echo e(url('clientdetails')); ?>">View</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\PhotoChat\resources\views/ViewClientDetails.blade.php ENDPATH**/ ?>