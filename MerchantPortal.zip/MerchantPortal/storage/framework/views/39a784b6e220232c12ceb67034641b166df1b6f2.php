
<?php $__env->startSection('stylecontent'); ?>
<style>
.pagination li {
    display: inline;
    margin-left: 0.5em;
    margin-right: 0.5em;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('maincontent'); ?>  
<table class="table table-bordered">
<thead>
<tr>
<th width="10%">CompanyName</th>
<th width="10%">CompanyLogo</th>
<th width="20%">Action</th>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $clientList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td width="10%"><?php echo e($client->CompanyName); ?></td>
<td width="10%"><img src="data:image/png;base64,<?php echo e(chunk_split(base64_encode(($client->CompanyLogo)))); ?>"  height="80" width="200"/></td>
<td><a href="<?php echo e(url('showClientDetails/'.$client->ClientID)); ?>" class="btn btn-primary">View</a><a href="<?php echo e(url('editClientDetails/'.$client->ClientID)); ?>" class="btn btn-warning">Edit</a><a href="<?php echo e(url('deleteClientDetails/'.$client->ClientID)); ?>" class="btn btn-danger">Delete</a></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<div class="pagination"><?php echo e($clientList->links()); ?></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidemenu'); ?>
<a href="<?php echo e(url('clientRegister')); ?>">Add</a>
<a href="<?php echo e(url('clientdetails')); ?>">View</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\PhotoChat\resources\views/ListOfClientDetails.blade.php ENDPATH**/ ?>