<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  
<style>
.pagination li {
    display: inline;
    margin-left: 0.5em;
    margin-right: 0.5em;
}
</style>
</head>
<body>
<div class="container">

<div class="row">
<?php $__currentLoopData = $productDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <div class="col-md-2">
  <div class="thumbnail">
<div class="card">
  
 <img id="img" src="data:image/png;base64,<?php echo e(chunk_split(base64_encode(($product->ProductImage)))); ?>"  height="180" width="80"/>
 <div class="caption">
 <a href="<?php echo e(url('product/'.$product->ProductID.'/'.$product->SubCategoryID)); ?>"><h5><b><?php echo e($product->ProductName); ?></b></h5> </a>
</div>
</div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<div class="pagination"><?php echo e($productDetails->links()); ?></div>
</body>
</html>
<?php /**PATH E:\Laravel\PhotoChat\resources\views/SimilarProducts.blade.php ENDPATH**/ ?>