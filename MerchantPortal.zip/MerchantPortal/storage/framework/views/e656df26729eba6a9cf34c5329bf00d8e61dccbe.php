
<?php $__env->startSection('maincontent'); ?>
<?php $__currentLoopData = $clientDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<form method="post" action="<?php echo e(url('updateClientDetails/'.$client->ClientID)); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="form-group">
<label class="col-md-4 text-right">Enter CompanyName</label>
<div class="col-md-4">
<input type="text" name="companyName" class="form-control input-sm" value="<?php echo e($client->CompanyName); ?>"/>
</div>
</div>
<br/><br/>
<div class="form-group">
<label class="col-md-4 text-right">Select CompanyLogo</label>
<div class="col-md-4">
<input type="file" name="companyLogo"/>
<img src="data:image/png;base64,<?php echo e(chunk_split(base64_encode(($client->CompanyLogo)))); ?>"  height="80" width="200"/>
<input type="hidden" name="hiddenImage" value="data:image/png;base64,<?php echo e(chunk_split(base64_encode(($client->CompanyLogo)))); ?>"/> 
</div>
</div>
<br/><br/><br/><br/><br/>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="form-group text-center">
<input type="submit" name="edit" class="btn btn-primary input-sm" value="Update"/>
</div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidemenu'); ?>
<a href="<?php echo e(url('clientRegister')); ?>">Add</a>
<a href="<?php echo e(url('clientdetails')); ?>">View</a>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\PhotoChat\resources\views/EditClientDetails.blade.php ENDPATH**/ ?>