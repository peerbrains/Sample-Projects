
<?php $__env->startSection('stylecontent'); ?>
<style>
.sidenav{
height:auto;
width:0px;
}
.show {

  width:400px;
  height:400px;
}

.main{
  margin-left:10px;
}
.subMenu
{
  height:0px;
}
</style>
<style>
.checkedrate {
  color: orange;
}
.unchecked{
  color:DarkKhaki;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('maincontent'); ?>
<?php $__currentLoopData = $productDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div style="width:40%; float:left;height:800px;">
<div class="show" href="data:image/png;base64,<?php echo e(chunk_split(base64_encode(($product->ProductImage)))); ?>">
<img id="show-img" style="margin:80px;" src="data:image/png;base64,<?php echo e(chunk_split(base64_encode(($product->ProductImage)))); ?>"  height="650" width="80%"/>
</div>
</div>
<div style="width:60%; float:right;height:800px;">
<h3 style="margin:30px;color:DarkSalmon;"><b><i><?php echo e(strtoupper($product->ProductName)); ?> </i></b></h3>
<h3 style="margin:30px;color:Red;"><b><i>Rs.<?php echo e($product->Amount); ?></i></b></h3>
<div style="margin:30px;">
<span  class="fa fa-star <?php echo ($product->Rating >= 1)?"checkedrate":"unchecked";?>"></span>
<span  class="fa fa-star <?php echo ($product->Rating >= 2)?"checkedrate":"unchecked"; ?>"></span>
<span  class="fa fa-star <?php echo ($product->Rating >= 3)?"checkedrate":"unchecked"; ?>"></span>
<span  class="fa fa-star <?php echo ($product->Rating >= 4)?"checkedrate":"unchecked"; ?>"></span>
<span  class="fa fa-star <?php echo ($product->Rating >= 5)?"checkedrate":"unchecked"; ?>"></span>
</div>
<h4 style="margin:30px;color:IndianRed;"><label>ProductSpecification:</label></h4>
<h4 style="margin-left:150px;color:LightSeaGreen;"><b>Size:</b><b style="margin-left:40px;color:Sienna;"><?php echo e($product->Size); ?></b></h4>
<h4 style="margin-left:139px;margin-top:15px;color:LightSeaGreen;"><b>Color:</b><b style="margin-left:40px;color:Sienna;"><?php echo e($product->Color); ?></b></h4>
<h4 style="margin-left:135px;margin-top:15px;color:LightSeaGreen;"><b>Brand:</b><b style="margin-left:40px;color:Sienna;"><?php echo e($product->Brand); ?></b></h4>
<h4 style="margin:30px;color:IndianRed;"><label>InternalOperations:</label></h4>
<?php $__currentLoopData = $internalOperationsArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $internalOperations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h4 style="margin-left:140px;margin-top:15px;color:SlateGrey;"><b><i><?php echo e($internalOperations); ?></i></b></h4>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<h4 style="margin-left:30px;margin-top:30px;margin-bottom:20px;color:IndianRed;"><label>ProductDescription:</label></h4>
<?php $__currentLoopData = $productDescriptionArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productDescription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h5 style="margin-left:150px;color:Indigo;"><?php echo e($productDescription); ?></h5>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<br/>
<div>
<h4 style="margin:30px;color:IndianRed;"><b><i>SimilarProducts:</i></b></h4>
<div class="container">
<div class="row">
<?php $__currentLoopData = $similarProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-2">
<div class="thumbnail">
<div class="card">
<img id="img" src="data:image/png;base64,<?php echo e(chunk_split(base64_encode(($product->ProductImage)))); ?>"  height="180" width="80"/>
<div class="caption">
<a href="<?php echo e(url('product/'.$product->ProductID.'/'.$product->SubCategoryID)); ?>"><h5><b><?php echo e($product->ProductName); ?></b></h5> </a>
</div>
</div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</div>
<div class="pagination"><?php echo e($similarProducts->links()); ?></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
<ul class="breadcrumb">
  <li><a href="#">Home</a></li>
  <?php $__currentLoopData = $subCategoryDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li><a href="<?php echo e(url('breadcrumbsubcategory/'.$subCategory->SubCategoryID)); ?>"><?php echo e($subCategory->SubCategoryName); ?></a></li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php $__currentLoopData = $productDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li><a href="#"><?php echo e($product->ProductName); ?></a></li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\PhotoChat\resources\views/ProductDescription.blade.php ENDPATH**/ ?>